# Run Summary – PI-10

**Date** : 2026-02-22 11:59:23  
**Source** : demo (données fictives)  

## Métriques

| Métrique | Valeur |
|----------|--------|
| Source utilisée | `demo (données fictives)` |
| PI | PI-10 |
| Nb équipes | 3 |
| Nb epics | 4 |
| Nb epics séparées | **0** |
| Nb features PI | 8 |
| Nb affectations | 9 |
| Nb personnes | 6 |
| Agents >100% | **1** |
| Agents multi-équipes | **1** |

## Fichiers Produits

| Statut | Type | Fichier |
|--------|------|---------|
| ✅ | draw.io | `output/orgchart.drawio` |
| ✅ | CSV fragmentation | `output/multi_affectations.csv` |
| ✅ | Synthèse MD | `output/synthesis.md` |
| ✅ | README | `output/README_generated.md` |

---

*Généré par grist-org-visualizer*