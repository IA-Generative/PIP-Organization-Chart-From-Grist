# Synthèse multi-affectations / fragmentation

Aucune affectation trouvée (table Affectations vide).