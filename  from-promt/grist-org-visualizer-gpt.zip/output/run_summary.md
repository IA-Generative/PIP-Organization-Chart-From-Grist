=== RUN SUMMARY ===
Source utilisée : fichier (/mnt/data/grist-org-visualizer/data/example_empty.grist)
PI : PI-10
Nb équipes : 0
Nb epics : 0
Nb epics séparées : 0
Nb features du PI : 0
Nb affectations : 0
Nb personnes : 0
Agents >100% : 0
Agents multi-équipes : 0
Features table vide : OUI
