# README généré — PI-10

Ce document est généré automatiquement à partir du fichier Grist SDID.

## Résumé

- PI : **PI-10**
- Équipes : **0**
- Epics : **0** (dont séparées : **0**)
- Features (PI) : **0**

## Lecture rapide

- **PM** : affichés au niveau **Équipe** (container).
- **PO** : affichés sur les **Epics séparées** (transverses/spécifiques).
- **Epic séparée** : si les personnes affectées à l’epic ne sont pas un sous-ensemble des personnes de l’équipe.

## Structure des sorties

- `orgchart.drawio` : diagramme organisationnel
- `multi_affectations.csv` + `synthesis.md` : fragmentation
- `PI-10_Synthese_SDID.pptx` : PowerPoint de synthèse
- `run_summary.md` : checklist d’exécution
